package org.d3if4075.Persegiku.data

data class BangunDatar(
    val nama:  String,
    val luas: String,
    val imageId: String
)
