package org.d3if4075.Persegiku

data class HasilPersegi(
    val sisi: Float,
    val keliling: Float,
    val luas: Float
)
